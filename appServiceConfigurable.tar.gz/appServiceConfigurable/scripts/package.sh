#!/bin/bash
PACKAGE_NAME=appServiceConfigurable
echo $PWD
rm -rf $PACKAGE_NAME
mkdir $PACKAGE_NAME
cp -r app-service-configurable scripts res $PACKAGE_NAME
cp scripts/start.sh $PACKAGE_NAME
tar -czvf $PACKAGE_NAME.tar.gz $PACKAGE_NAME
rm -rf $PACKAGE_NAME
