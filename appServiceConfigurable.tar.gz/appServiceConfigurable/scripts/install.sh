#!/bin/bash
SERVICE=appServiceConfigurable.service
sudo cp ./scripts/${SERVICE} /lib/systemd/system
sudo systemctl daemon-reload
sudo systemctl enable ${SERVICE}
sudo systemctl restart ${SERVICE}
