#!/bin/bash
/opt/appServiceConfigurable/app-service-configurable -sk MqttExport -c=/opt/appServiceConfigurable/res -p mqtt-export
