#!/bin/bash
/opt/appServiceConfigurable/app-service-configurable -sk RuiTing-MqttExport -c=/opt/appServiceConfigurable/res -p mqtt-export
